package Model;

import java.util.Date;

public class MilitanzaPortiere extends Militanza{
    private int goalSubiti = 0;
    public MilitanzaPortiere(Giocatore g, Squadra s, Date dataInizio, Date dataFine, int partiteGiocate, int goalSegnati, int cartelliniGialli, int cartelliniRossi, int assist, int goalSubiti) {
        super(g, s, dataInizio, dataFine, partiteGiocate, goalSegnati, cartelliniGialli, cartelliniRossi, assist);
        this.goalSubiti = goalSubiti;
    }
    public void setGoalSubiti(int goalSubiti){
        this.goalSubiti = goalSubiti;
    }
    public int getGoalSubiti(){
        return goalSubiti;
    }
}
