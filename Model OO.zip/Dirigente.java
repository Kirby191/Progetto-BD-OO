package Model;
import java.util.ArrayList;
import java.util.Date;

public class Dirigente {
    private String nome;
    private String cognome;
    private char sesso;
    private String SSN;
    private Date inizioD;
    private Date fineD;
    private String ruoloDirigente;
    private Giocatore giocatore = null;
    private ArrayList<Squadra> squadreDirette = new ArrayList<>();
    public Dirigente(Giocatore g, ArrayList<Squadra> s, String nome, String cognome, char sesso, String SSN, Date inizioD, Date fineD) {
        giocatore = g;
        squadreDirette = s;
        this.nome = nome;
        this.cognome = cognome;
        this.sesso = sesso;
        this.SSN = SSN;
        this.inizioD = inizioD;
        this.fineD = fineD;
    }
    /*da vedere se necessari e se logicamente giusti
    public void setGiocatore(Giocatore g){
        this.giocatore = g;
    }
    public Giocatore getGiocatore(){
        return giocatore;
    }*/
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setCognome(String cognome){
        this.cognome = cognome;
    }
    public void setSesso(char sesso){
        this.sesso = sesso;
    }
    public void setSSN(String SSN){
        this.SSN = SSN;
    }
    public void setInizioA(Date inizioA){
        this.inizioD = inizioA;
    }
    public void setFineA(Date fineA){
        this.fineD = fineA;
    }
    public void setRuoloDirigente(String ruoloDirigente){
        this.ruoloDirigente = ruoloDirigente;
    }
    public String getNome(){
        return nome;
    }
    public String getCognome(){
        return cognome;
    }
    public char getSesso() {
        return sesso;
    }
    public String getSSN(){
        return SSN;
    }
    public Date getInizioA(){
        return inizioD;
    }
    public Date getFineA(){
        return fineD;
    }
    public String getRuoloDirigente(){
        return ruoloDirigente;
    }
    public void setGiocatore(Giocatore g){
        giocatore = g;
    }
    public Giocatore getGiocatore(){
        return giocatore;
    }
}
