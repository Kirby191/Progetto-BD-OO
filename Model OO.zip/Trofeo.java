package Model;
import java.util.ArrayList;
import java.util.Date;

public class Trofeo {
    private String nomeTrofeo;
    private Date annoTrofeo;
    private boolean isSquadra;
    private ArrayList<Giocatore> giocatori = new ArrayList<>();
    private Squadra squadra = null;
    public Trofeo(String nomeTrofeo, Date annoTrofeo, boolean isSquadra) {
        this.nomeTrofeo = nomeTrofeo;
        this.annoTrofeo = annoTrofeo;
        this.isSquadra = isSquadra;
    }
    public void setVincitaTrofeo(Giocatore g) {
        // Gui da errore se non è individuale
        if(isSquadra)
            return;
        giocatori.add(g);
        g.getTrofei_vinti().add(this);
    }
    //Nel momento in cui io chiamo il metodo con la squadra, voglio che il controller mi aggiunta
    // il trofeo a tutti i giocatori della squadra
    public void setVincitaTrofeo(Squadra s) {
        // Gui da errore se non è di squadra
        if(!isSquadra)
            return;
        squadra = s;
        s.getTrofei().add(this);
    }
    public void setNomeTrofeo(String nomeTrofeo){
        this.nomeTrofeo = nomeTrofeo;
    }
    public void setAnnoTrofeo(Date annoTrofeo){
        this.annoTrofeo = annoTrofeo;
    }
    public void setIsSquadra(Boolean isSquadra){
        this.isSquadra = isSquadra;
    }

    public String getNomeTrofeo(){
        return nomeTrofeo;
    }
    public Date getAnnoTrofeo() {
        return annoTrofeo;
    }
    public boolean isSquadra() {
        return isSquadra;
    }
}
