package Model;
import java.util.ArrayList;
import java.util.Date;

public class Giocatore {
    private String nome;
    private String cognome;
    private String SSN;
    private String nazionalita;
    private Date dataNascita;
    private char sesso;
    private char piede;
    private float altezza;
    private float peso;
    private String ruolo;
    private boolean ritirato;
    private String abilita;
    private ArrayList<Militanza> storico_militanze = new ArrayList<>();
    private ArrayList <Squadra> storico_squadre = new ArrayList<>();
    private ArrayList <Trofeo> trofei_vinti = new ArrayList<>();
    private Allenatore allenatore = null;
    private Dirigente dirigente = null;
    public Giocatore(Militanza c) {
        storico_militanze.add(c);
        c.setProprietario(this);
    }
    public Giocatore(String nome, String cognome, String SSN, String nazionalita, Date dataNascita,char sesso, char piede,float altezza, float peso,String ruolo, Boolean ritirato, String abilita) {
        this.nome = nome;
        this.cognome = cognome;
        this.SSN = SSN;
        this.nazionalita = nazionalita;
        this.dataNascita = dataNascita;
        this.sesso = sesso;
        this.piede = piede;
        this.altezza = altezza;
        this.peso = peso;
        this.ruolo = ruolo;
        this.ritirato = ritirato;
        this.abilita = abilita;
    }
    /*modifiche nelle funzioni ExGiocatoreA ed ExGiocatoreD dove adesso si utilizza la funzione setGiocatore
    metodi creati in allenatore e dirigente*/
    public void ExGiocatoreA(Allenatore a) {
        // Giocatore deve essere ritirato: Controller
        allenatore = a;
        a.setGiocatore(this);
    }
    public void ExGiocatoreD(Dirigente d) {
        // Giocatore deve essere ritirato: Controller
        dirigente = d;
        d.setGiocatore(this);
    }
    public void addTrofeo(Trofeo t) {
        trofei_vinti.add(t);
    }
    public void addSquadra(Squadra s) {
        storico_squadre.add(s);
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setCognome(String cognome) {
        this.cognome = cognome;
    }
    public void setSSN(String SSN) {
        this.SSN = SSN;
    }
    public void setNazionalita(String nazionalita) {
        this.nazionalita = nazionalita;
    }
    public void setDataNascita(Date dataNascita) {
        this.dataNascita = dataNascita;
    }
    public void setPiede(char piede) {
        this.piede = piede;
    }
    public void setAltezza(float altezza) {
        this.altezza = altezza;
    }
    public void setPeso(float peso) {
        this.peso = peso;
    }
    public void setRuolo(String ruolo) {
        this.ruolo = ruolo;
    }
    public void setSesso(char sesso) {
        this.sesso = sesso;
    }
    public void setRitirato(boolean ritirato) {
        this.ritirato = ritirato;
    }
    public void setAbilita(String abilita) {
        this.abilita = abilita;
    }
    public String getNome() {
        return nome;
    }
    public String getCognome() {
        return cognome;
    }
    public String getSSN() {
        return SSN;
    }
    public String getNazionalita() {
        return nazionalita;
    }
    public Date getDataNascita() {
        return dataNascita;
    }
    public char getPiede() {
        return piede;
    }
    public float getAltezza() {
        return altezza;
    }
    public float getPeso() {
        return peso;
    }
    public String getRuolo() {
        return ruolo;
    }
    public char getSesso() {
        return sesso;
    }
    public boolean isRitirato() {
        return ritirato;
    }
    public String getAbilita() {
        return abilita;
    }
    public Allenatore getAllenatore() {
        return allenatore;
    }
    public Dirigente getDirigente() {
        return dirigente;
    }
    public ArrayList<Trofeo> getTrofei_vinti() {
        return trofei_vinti;
    }
    public ArrayList<Squadra> getStorico_squadre() {
        return storico_squadre;
    }
    public ArrayList<Militanza> getStorico_militanze() {
        return storico_militanze;
    }
    public void aggiuntiMilitanza(Militanza m) {
        storico_militanze.add(m);
    }
}