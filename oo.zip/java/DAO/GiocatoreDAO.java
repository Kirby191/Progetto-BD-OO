package DAO;

public class GiocatoreDAO {
}
