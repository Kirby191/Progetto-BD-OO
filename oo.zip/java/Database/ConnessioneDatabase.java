package Database;

public class ConnessioneDatabase {
}
