package ImplementazioneDAO;

public class ImplementazionePostgresDAO {
}
