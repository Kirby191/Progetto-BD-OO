package Model;

public class Allenatore {
    Giocatore giocatore = null;
    public Allenatore(Giocatore g) {
        giocatore = g;
    }
    public Allenatore () {
    }
}
