package Model;
import java.util.ArrayList;

public class Giocatore {
    ArrayList<Militanza> Militanze = new ArrayList<>();
    Allenatore allenatore = null;
    Dirigente dirigente = null;
    public Giocatore(Militanza c) {
        Militanze.add(c);
        c.proprietario = this;
    }
    public Giocatore() {
        Militanze.add(new Militanza(this));
    }
    public Giocatore(Allenatore a) {
        allenatore = a;
        a.giocatore = this;
        Militanze.add(new Militanza(this));
    }
    public Giocatore(Dirigente d)
    {
        dirigente = d;
        d.giocatore = this;
        Militanze.add(new Militanza(this));
    }
}