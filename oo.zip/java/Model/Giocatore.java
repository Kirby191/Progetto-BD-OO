package Model;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class Giocatore {
    private ArrayList<Militanza> militanze = new ArrayList<>();
    private ArrayList <Squadra> squadre = new ArrayList<>();
    private ArrayList <Trofeo> trofei = new ArrayList<>();
    Allenatore allenatore = null;
    Dirigente dirigente = null;
    public Giocatore(Militanza c) {
        militanze.add(c);
        c.setProprietario(this);
    }
    public Giocatore() {
        militanze.add(new Militanza(this));
    }
    public void ExGiocatoreA(Allenatore a) {
        // Giocatore deve essere ritirato
        allenatore = a;
        a.giocatore = this;
    }
    public void ExGiocatoreD(Dirigente d) {
        // Giocatore deve essere ritirato
        dirigente = d;
        d.giocatore = this;
    }
    public ArrayList<Trofeo> getTrofei() {
        return trofei;
    }
    public ArrayList<Squadra> getSquadre() {
        return squadre;
    }
    public ArrayList<Militanza> getMilitanze() {
        return militanze;
    }
}