package Model;

public class MilitanzaPortiere extends Militanza{
    public MilitanzaPortiere(Giocatore g) {
        super(g);
    }
    public MilitanzaPortiere() {
        super();
    }
}
