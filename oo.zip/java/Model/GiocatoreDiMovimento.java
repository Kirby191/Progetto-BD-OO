package Model;

public class GiocatoreDiMovimento extends Giocatore{
    public GiocatoreDiMovimento(Giocatore g) {
        super();
    }
    public GiocatoreDiMovimento() {
        super();
    }
}
