package Model;
import java.util.ArrayList;

public class Trofeo {
    private boolean isSquadra;
    ArrayList<Giocatore> giocatori = new ArrayList<>();
    Squadra squadra = null;
    public Trofeo() {
    }
    public void setVincitaTrofeo(Giocatore g) {
        // Gui da errore se non è individuale
        if(isSquadra)
            return;
        giocatori.add(g);
        g.getTrofei().add(this);
    }

    public void setVincitaTrofeo(Squadra s) {
        // Gui da errore se non è di squadra
        if(!isSquadra)
            return;
        squadra = s;
        s.getTrofei().add(this);
    }
}
