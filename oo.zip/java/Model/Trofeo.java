package Model;

public class Trofeo {
}
