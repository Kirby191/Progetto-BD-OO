package Model;

public class Portiere extends Giocatore{
    public Portiere(Giocatore g) {
        super();
    }
    public Portiere() {
        super();
    }
}
