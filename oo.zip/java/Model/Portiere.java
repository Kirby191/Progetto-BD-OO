package Model;

public class Portiere extends Giocatore{
}
