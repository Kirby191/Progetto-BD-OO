package Model;

public class Dirigente {
    Giocatore giocatore = null;
    public Dirigente(Giocatore g) {
        giocatore = g;
    }
    public Dirigente () {
    }
}
