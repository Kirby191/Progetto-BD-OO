package Model;

import java.util.ArrayList;

public class Squadra {
    String nome;
    private ArrayList<Militanza> militanze = new ArrayList<>();
    private ArrayList<Giocatore> giocatori = new ArrayList<>();
    private ArrayList<Trofeo> trofei = new ArrayList<>();
    //Controller deve controllare ArrayList<Giocatore> g;
    public Squadra(ArrayList<Giocatore> g) {
        int size = g.size()-1;
        int i = 0;
        if(g.size() >= 11)
            while (i < size)
            {
                giocatori.add(g.remove(i));
                i++;
            }
        else// Qui va una gui
            System.out.println("Non ci sono abbastanza giocatori per creare una squadra");
    }
    public ArrayList<Giocatore> getGiocatori() {
        return giocatori;
    }
    public ArrayList<Militanza> getMilitanze() {
        return militanze;
    }
    public ArrayList<Trofeo> getTrofei() {
        return trofei;
    }
}
