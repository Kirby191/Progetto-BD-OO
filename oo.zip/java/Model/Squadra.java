package Model;

import java.util.ArrayList;

public class Squadra {
    ArrayList<Militanza> militanze = new ArrayList<>();
    ArrayList<Giocatore> giocatori = new ArrayList<>();
    public Squadra(Militanza m) {
        militanze.add(m);
        giocatori.add(m.proprietario);
        m.squadra = this;
    }
    public Squadra() {
        for (int i = 0; i < 11; i++) {
            militanze.add(new Militanza(this));
            giocatori.add(militanze.get(i).proprietario);
        }
    }
}
