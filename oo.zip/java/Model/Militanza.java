package Model;

public class Militanza {
    private Giocatore proprietario;
    private Squadra squadra;
    public Militanza(Giocatore g, Squadra s) {
        g.getSquadre().add(s);
        proprietario = g;
        squadra = s;
        s.getMilitanze().add(this);
    }
    public Militanza(Giocatore g) {
        proprietario = g;
        squadra = null;
    }
    public Squadra getSquadra() {
        return squadra;
    }
    public Giocatore getProprietario() {
        return proprietario;
    }
    public void setProprietario(Giocatore g) {
        proprietario = g;
    }
}
