package Model;

public class Militanza {
    Giocatore proprietario;
    Squadra squadra;
    public Militanza(Giocatore g) {
        proprietario = g;
        squadra = new Squadra(this);
    }
    public Militanza() {
        proprietario = new Giocatore(this);
        squadra = new Squadra(this);
    }
    public Militanza(Giocatore g, Squadra s) {
        proprietario = g;
        squadra = s;
    }
    public Militanza (Squadra s) {
        proprietario = new Giocatore(this);
        squadra = s;
    }
    public Squadra getSquadra() {
        return squadra;
    }
    public Giocatore getProprietario() {
        return proprietario;
    }
}
