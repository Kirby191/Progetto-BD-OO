package Model;
import java.util.Date;

public class Militanza {
    private Date dataInizio;
    private Date dataFine;
    private int partiteGiocate;
    private int golSegnati;
    private int cartelliniGialli;
    private int cartelliniRossi;
    private int assist;

    private Giocatore proprietario;
    private Squadra squadra;
    public Militanza(Giocatore g, Squadra s, Date dataInizio, Date dataFine, int partiteGiocate,
                     int goalSegnati, int cartelliniGialli, int cartelliniRossi, int assist) {
        proprietario = g;
        squadra = s;
        this.dataInizio = dataInizio;
        this.dataFine = dataFine;
        this.partiteGiocate = partiteGiocate;
        this.golSegnati = goalSegnati;
        this.cartelliniGialli = cartelliniGialli;
        this.cartelliniRossi = cartelliniRossi;
        this.assist = assist;
        s.getMilitanze().add(this);
        g.getStorico_militanze().add(this);
        g.getStorico_squadre().add(squadra);
    }
    public Squadra getSquadra() {
        return squadra;
    }
    public Giocatore getProprietario() {
        return proprietario;
    }
    public void setProprietario(Giocatore g) {
        proprietario = g;
    }
    public void setDataInizio(Date dataInizio){
        this.dataInizio = dataInizio;
    }
    public void setDataFine(Date dataFine){
        this.dataFine = dataFine;
    }
    public void setPartiteGiocate(int partiteGiocate){
        this.partiteGiocate = partiteGiocate;
    }
    public void setGolSegnati(int golSegnati){
        this.golSegnati = golSegnati;
    }
    public void setCartelliniGialli(int cartelliniGialli){
        this.cartelliniGialli = cartelliniGialli;
    }
    public void setCartelliniRossi(int cartelliniRossi){
        this.cartelliniRossi = cartelliniRossi;
    }
    public void setAssist(int assist){
        this.assist = assist;
    }
    public Date getDataInizio(){
        return dataInizio;
    }
    public Date getDataFine(){
        return dataFine;
    }
    public int getPartiteGiocate(){
        return partiteGiocate;
    }
    public int getGolSegnati(){
        return golSegnati;
    }
    public int getCartelliniGialli(){
        return cartelliniGialli;
    }
    public int getCartelliniRossi(){
        return cartelliniRossi;
    }
    public int getAssist(){
        return assist;
    }
}
