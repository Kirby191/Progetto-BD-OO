package Model;
import java.util.ArrayList;
import java.util.Date;

public class Allenatore {
    private String nome;
    private String cognome;
    private char sesso;
    private String SSN;
    private Date inizioA;
    private Date fineA;
    private Giocatore giocatore = null;
    private ArrayList<Squadra> squadreAllenate = new ArrayList<>();
    //si dovrebbe fare un altro costruttore in caso l'allenatore non sia un ex giocatore
    public Allenatore(Giocatore g, ArrayList<Squadra> s, String nome, String cognome, char sesso, String SSN, Date inizioA, Date fineA) {
        giocatore = g;
        squadreAllenate = s;
        this.nome = nome;
        this.cognome = cognome;
        this.sesso = sesso;
        this.SSN = SSN;
        this.inizioA = inizioA;
        this.fineA = fineA;
    }
    public Giocatore getGiocatore(){
        return giocatore;
    }
    public void setGiocatore(Giocatore g){
        giocatore = g;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setCognome(String cognome){
        this.cognome = cognome;
    }
    public void setSesso(char sesso){
        this.sesso = sesso;
    }
    public void setSSN(String SSN){
        this.SSN = SSN;
    }
    public void setInizioA(Date inizioA){
        this.inizioA = inizioA;
    }
    public void setFineA(Date fineA){
        this.fineA = fineA;
    }
    public String getNome(){
        return nome;
    }
    public String getCognome(){
        return cognome;
    }
    public char getSesso() {
        return sesso;
    }
    public String getSSN(){
        return SSN;
    }
    public Date getInizioA(){
        return inizioA;
    }
    public Date getFineA(){
        return fineA;
    }
}