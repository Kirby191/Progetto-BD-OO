package Model;

import java.util.ArrayList;
import java.util.Date;

public class Squadra {
    private String nomeSquadra;
    private String nazionalita;
    private Date dataFondazione;

    private ArrayList<Militanza> militanze = new ArrayList<>();
    private ArrayList<Giocatore> giocatori = new ArrayList<>();
    private ArrayList<Trofeo> trofei = new ArrayList<>();
    private Allenatore allenatore;
    private ArrayList<Dirigente> dirigenti = new ArrayList<>();
    //Controller deve controllare ArrayList<Giocatore> g;
    public Squadra(ArrayList<Giocatore> g, Allenatore a, ArrayList<Dirigente> d, String nomeSquadra, String nazionalita, Date dataFondazione) {
        // Controller deve controllare ArrayList<Giocatore> g, non il model!
        int size = g.size()-1;
        int i = 0;
        if(g.size() >= 11) {
            while (i < size) {
                giocatori.add(g.remove(i));
                i++;
            }
            allenatore = a;
            dirigenti = d;
            this.nomeSquadra = nomeSquadra;
            this.nazionalita = nazionalita;
            this.dataFondazione = dataFondazione;
        }
        else// Qui va un return al controller con un flag di fallimento come te
            System.out.println("Non ci sono abbastanza giocatori per creare una squadra");
    }
    public ArrayList<Giocatore> getGiocatori() {
        return giocatori;
    }
    public ArrayList<Militanza> getMilitanze() {
        return militanze;
    }
    public ArrayList<Trofeo> getTrofei() {
        return trofei;
    }
    public void setNomeSquadra(String nomeSquadra){
        this.nomeSquadra = nomeSquadra;
    }
    public void setNazionalita(String nazionalita){
        this.nazionalita = nazionalita;
    }
    public void setDataFondazione(Date dataFondazione){
        this.dataFondazione = dataFondazione;
    }
    public String getNomeSquadra(){
        return nomeSquadra;
    }
    public String getNazionalita(){
        return nazionalita;
    }
    public Date getDataFondazione(){
        return dataFondazione;
    }
}
