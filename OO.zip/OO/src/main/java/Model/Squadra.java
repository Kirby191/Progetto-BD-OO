package Model;

import java.util.ArrayList;
import java.util.Date;

/**
 * The type Squadra.
 */
public class Squadra {
    private String nomeSquadra;
    private String nazionalita;
    private Date dataFondazione;

    private ArrayList<Militanza> militanze = new ArrayList<>();
    private ArrayList<Giocatore> giocatori = new ArrayList<>();
    private ArrayList<Trofeo> trofei = new ArrayList<>();
    private Allenatore allenatore;
    private ArrayList<Dirigente> dirigenti = new ArrayList<>();

    /**
     * Instantiates a new Squadra.
     *
     * @param g              the g
     * @param a              the a
     * @param d              the d
     * @param nomeSquadra    the nome squadra
     * @param nazionalita    the nazionalita
     * @param dataFondazione the data fondazione
     */
//Controller deve controllare ArrayList<Giocatore> g;
    public Squadra(ArrayList<Giocatore> g, Allenatore a, ArrayList<Dirigente> d, String nomeSquadra, String nazionalita, Date dataFondazione) {
        // Controller deve controllare ArrayList<Giocatore> g, non il model!
        int size = g.size()-1;
        int i = 0;
        if(g.size() >= 11) {
            while (i < size) {
                giocatori.add(g.remove(i));
                i++;
            }
            allenatore = a;
            dirigenti = d;
            this.nomeSquadra = nomeSquadra;
            this.nazionalita = nazionalita;
            this.dataFondazione = dataFondazione;
        }
        else// Qui va un return al controller con un flag di fallimento come te
            System.out.println("Non ci sono abbastanza giocatori per creare una squadra");
    }

    /**
     * Gets giocatori.
     *
     * @return the giocatori
     */
    public ArrayList<Giocatore> getGiocatori() {
        return giocatori;
    }

    /**
     * Gets militanze.
     *
     * @return the militanze
     */
    public ArrayList<Militanza> getMilitanze() {
        return militanze;
    }

    /**
     * Gets trofei.
     *
     * @return the trofei
     */
    public ArrayList<Trofeo> getTrofei() {
        return trofei;
    }

    /**
     * Set nome squadra.
     *
     * @param nomeSquadra the nome squadra
     */
    public void setNomeSquadra(String nomeSquadra){
        this.nomeSquadra = nomeSquadra;
    }

    /**
     * Set nazionalita.
     *
     * @param nazionalita the nazionalita
     */
    public void setNazionalita(String nazionalita){
        this.nazionalita = nazionalita;
    }

    /**
     * Set data fondazione.
     *
     * @param dataFondazione the data fondazione
     */
    public void setDataFondazione(Date dataFondazione){
        this.dataFondazione = dataFondazione;
    }

    /**
     * Get nome squadra string.
     *
     * @return the string
     */
    public String getNomeSquadra(){
        return nomeSquadra;
    }

    /**
     * Get nazionalita string.
     *
     * @return the string
     */
    public String getNazionalita(){
        return nazionalita;
    }

    /**
     * Get data fondazione date.
     *
     * @return the date
     */
    public Date getDataFondazione(){
        return dataFondazione;
    }
}
