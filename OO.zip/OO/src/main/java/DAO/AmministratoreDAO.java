package DAO;

public interface AmministratoreDAO {
}
