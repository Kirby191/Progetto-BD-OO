package DAO;

import java.sql.Date;
import Model.Giocatore;

public interface GiocatoreDAO {
    boolean ControlloCredenziali(String username, String password);
    void RegistrazioneGiocatore(String SSN, String username, String password);
    void UpdateGiocatore(String nome, String cognome, String nazionalita, Date dataNascita,
                         char sesso, char piede, float altezza, float peso,
                         String ruolo, Boolean ritirato, String abilita, char TipoGiocatore, String SSN);
    boolean ControlloSSNEsistente(String SSN);

    Giocatore getGiocatoreFromUsername(String username);

    void CarFisicheRicercaGiocatore(String nome, String cognome, Date dataNascita, String piede, String ruolo, String sesso, String ordineNascite);

    void TabellaDaQuery(String query, String[] colonne);
}
