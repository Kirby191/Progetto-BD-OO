package DAO;

public interface MilitanzaDAO {
    void RicercaCarrieraGiocatore(String SSN);
}
