package Controller;

import DAO.MilitanzaDAO;
import ImplementazioneDAO.ImpDAOGiocatori;
import ImplementazioneDAO.ImpDAOMilitanza;
import Model.*;
import DAO.GiocatoreDAO;

import javax.swing.*;
import java.sql.Date;
import java.util.ArrayList;

public class Controller {
    private static JFrame currentFrame;
    private final GiocatoreDAO DAOGiocatore = new ImpDAOGiocatori();

    private final MilitanzaDAO DAOMilitanza = new ImpDAOMilitanza();

    public Controller() {
    }

    Giocatore g;
    Squadra s;
    Allenatore a;
    Dirigente d;
    Militanza m;
    Trofeo t;
    MilitanzaPortiere mp;
    public void CreateGiocatore(String nome, String cognome, String SSN, String nazionalita, Date dataNascita,
                                 char sesso, char piede, float altezza, float peso,
                                String ruolo, Boolean ritirato, String abilita, char tipoGiocatore) {
         g = new Giocatore(nome, cognome, SSN, nazionalita, dataNascita,
                sesso, piede, altezza, peso, ruolo, ritirato, abilita, tipoGiocatore);
    }
    public void CreateSquadra(ArrayList<Model.Giocatore> g, Model.Allenatore a, ArrayList<Model.Dirigente> d,
                              String nomeSquadra, String nazionalita, Date dataFondazione) {
        s = new Squadra(g, a, d, nomeSquadra, nazionalita, dataFondazione);
    }
    public void CreateAllenatore(Model.Giocatore g, ArrayList<Model.Squadra> s, String nome, String cognome, char sesso,
                                 String SSN, Date inizioA, Date fineA) {
        a = new Allenatore(g, s, nome, cognome, sesso, SSN, inizioA, fineA);
    }
    public void CreateDirigente(Model.Giocatore g, ArrayList<Model.Squadra> s, String nome, String cognome, char sesso,
                                String SSN, Date inizioD, Date fineD) {
        d = new Dirigente(g, s, nome, cognome, sesso, SSN, inizioD, fineD);
    }
    public void CreateMilitanza(Model.Giocatore g, Model.Squadra s, Date dataInizio, Date dataFine, int partiteGiocate,
                                int goalSegnati, int cartelliniGialli, int cartelliniRossi, int assist) {
        m = new Militanza(g, s, dataInizio, dataFine,
                partiteGiocate, goalSegnati, cartelliniGialli, cartelliniRossi, assist);
    }
    public void CreateTrofeo(String nomeTrofeo, Date annoTrofeo, boolean isSquadra) {
       t = new Trofeo(nomeTrofeo, annoTrofeo, isSquadra);
    }
    public void CreateMilitanzaPortiere (Giocatore g, Squadra s, Date dataInizio, Date dataFine,
                                         int partiteGiocate, int goalSegnati, int cartelliniGialli,
                                         int cartelliniRossi, int assist, int goalSubiti) {
       mp = new Model.MilitanzaPortiere(g, s, dataInizio, dataFine, partiteGiocate,
                goalSegnati, cartelliniGialli, cartelliniRossi, assist, goalSubiti);
    }

    public boolean ControlloSSN(String SSN) {
        if (SSN.length() == 11) {
            // Verifica il formato del SSN
            for (int i = 0; i < 11; i++) {
                // Se l'indice è un trattino, controlla se è nella posizione corretta
                if (i == 3 || i == 7) {
                    if (SSN.charAt(i) != '-') {
                        JOptionPane.showMessageDialog(null, "Formato SSN non corretto!");
                        return false;
                    }
                } else {
                    // Altrimenti, controlla se è un numero
                    if (!Character.isDigit(SSN.charAt(i))) {
                        JOptionPane.showMessageDialog(null, "Formato SSN non corretto!");
                        return false;
                    }
                }
            }
            //Se trovo l'SSN nel database, ritorno true
            return getGiocatoreDAO().ControlloSSNEsistente(SSN);
        }
        JOptionPane.showMessageDialog(null, "SSN ha una lunghezza non valida");
        return false;
    }
    public GiocatoreDAO getGiocatoreDAO() {
        return DAOGiocatore;
    }

    public String InserisciValoriGiocatore(JTextField nomeTextField, JTextField cognomeTextField, JTextField nazionalitàTextField, JTextField dataNascitaTextField,
                                         JComboBox piedeComboBox, JTextField altezzaTextField, JTextField pesoTextField, JComboBox ruoloComboBox, JComboBox ritiratoComboBox,
                                         JTextField abilitàTextField, JComboBox tipoGiocatoreComboBox, JComboBox sessoComboBox, String username) {
        Giocatore g = getGiocatoreDAO().getGiocatoreFromUsername(username);

        piedeComboBox.addItem('D');
        piedeComboBox.addItem('S');
        piedeComboBox.setSelectedItem(g.getPiede());

        String[] ruoli = {"Portiere", "DifensoreCentrale", "TerzinoSinistro", "TerzinoDestro", "CentrocampistaDifensivo", "CentrocampistaCentrale", "EsternoSinistro", "EsternoDestro", "CentrocampistaOffensivo", "AlaSinistra", "AlaDestra", "Trequartista", "Punta"};
        for (String ruolod : ruoli) {
            ruoloComboBox.addItem(ruolod);
        }

        ruoloComboBox.setSelectedItem(g.getRuolo());

        sessoComboBox.addItem('M');
        sessoComboBox.addItem('F');

        sessoComboBox.setSelectedItem(g.getSesso());

        tipoGiocatoreComboBox.addItem('M');
        tipoGiocatoreComboBox.addItem('P');
        tipoGiocatoreComboBox.setSelectedItem(g.getTipoGiocatore());

        ritiratoComboBox.addItem("True");
        ritiratoComboBox.addItem("False");
        ritiratoComboBox.setSelectedItem(g.isRitirato() ? "True" : "False");
        nomeTextField.setText(g.getNome());
        cognomeTextField.setText(g.getCognome());
        nazionalitàTextField.setText(g.getNazionalita());
        dataNascitaTextField.setText(g.getDataNascita().toString());
        altezzaTextField.setText(String.valueOf(g.getAltezza()));
        pesoTextField.setText(String.valueOf(g.getPeso()));
        abilitàTextField.setText(g.getAbilita());

        return g.getSSN();
    }

    public void ModificaGiocatore(JTextField nomeTextField, JTextField cognomeTextField, JTextField nazionalitaTextField, JTextField dataNascitaTextField,
                                         JComboBox piedeComboBox, JTextField altezzaTextField, JTextField pesoTextField, JComboBox ruoloComboBox, JComboBox ritiratoComboBox,
                                         JTextField abilitàTextField, JComboBox tipoGiocatoreComboBox, JComboBox sessoComboBox, String username, String SSN) {
        String ritirato = (String) ritiratoComboBox.getSelectedItem();

        getGiocatoreDAO().UpdateGiocatore(
                nomeTextField.getText(),
                cognomeTextField.getText(),
                nazionalitaTextField.getText(),
                Date.valueOf(dataNascitaTextField.getText()),
                (char) sessoComboBox.getSelectedItem(),
                (char) piedeComboBox.getSelectedItem(),
                Float.parseFloat(altezzaTextField.getText()),
                Float.parseFloat(pesoTextField.getText()),
                (String) ruoloComboBox.getSelectedItem(),
                ritirato.equals("True") ? true : false,
                abilitàTextField.getText(),
                (char) tipoGiocatoreComboBox.getSelectedItem(),
                SSN
        );
    }

    public void RicercaGiocatore(JTextField nomeTextField, JTextField cognomeTextField, JTextField annoNascitaTextField, JComboBox piedeComboBox, JComboBox ruoloComboBox, JComboBox sessoComboBox, JComboBox etàComboBox) {
        Date dataNascita = null;
        if(!annoNascitaTextField.getText().isEmpty())
            dataNascita = Date.valueOf(annoNascitaTextField.getText());


        getGiocatoreDAO().CarFisicheRicercaGiocatore(
                nomeTextField.getText(),
                cognomeTextField.getText(),
                dataNascita,
                piedeComboBox.getSelectedItem().toString(),
                ruoloComboBox.getSelectedItem().toString(),
                sessoComboBox.getSelectedItem().toString(),
                etàComboBox.getSelectedItem().toString());
    }

    public void setCurrentFrame(JFrame frame) {
        currentFrame = frame;
    }

    public static JFrame getCurrentFrame() {
        return currentFrame;
    }

    public MilitanzaDAO getMilitanzaDAO() {
        return DAOMilitanza;
    }
    public void fillBaseValues(JComboBox piedeComboBox, JComboBox sessoComboBox, JComboBox ruoloComboBox)
    {
            piedeComboBox.addItem(' ');
            piedeComboBox.addItem('D');
            piedeComboBox.addItem('S');

            sessoComboBox.addItem(' ');
            sessoComboBox.addItem('M');
            sessoComboBox.addItem('F');

            String[] ruoli = {" ", "Portiere", "DifensoreCentrale", "TerzinoSinistro", "TerzinoDestro", "CentrocampistaDifensivo", "CentrocampistaCentrale", "EsternoSinistro", "EsternoDestro", "CentrocampistaOffensivo", "AlaSinistra", "AlaDestra", "Trequartista", "Punta"};
            for (String ruolod : ruoli) {
                ruoloComboBox.addItem(ruolod);
            }
    }
}