package ImplementazioneDAO;

import Database.ConnessioneDatabase;

import javax.swing.*;
import java.sql.*;

public class ImpDAOAmministratore {
    private Connection conn;
    public ImpDAOAmministratore() {
        try {
            conn = ConnessioneDatabase.getInstance(3).connection;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public boolean ControlloCredenziali(String username, String password) {
        //Da controllare
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM Amministratore WHERE Username = ? AND Password = ?")) {

            ((PreparedStatement) st).setString(1, username);
            ((PreparedStatement) st).setString(2, password);

            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Benvenuto " + username);
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Credenziali errate");
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            return false;
        }
    }
}
