package ImplementazioneDAO;
import Database.ConnessioneDatabase;
import DAO.GiocatoreDAO;
import GUI.ResultTabella;
import Model.Giocatore;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import Controller.Controller;

public class ImpDAOGiocatori implements GiocatoreDAO{
    private Connection conn;
    public ImpDAOGiocatori() {
        try {
            conn = ConnessioneDatabase.getInstance(2).connection;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean ControlloCredenziali(String username, String password) {
        try (PreparedStatement st = conn.prepareStatement("SELECT * FROM Credenziali WHERE Username = ? AND Password = ? AND Ruolo = 'Giocatore'")) {
            st.setString(1, username);
            st.setString(2, password);

            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                return true;
            }

            if (username.isEmpty()) {
                if(password.isEmpty())
                {
                    JOptionPane.showMessageDialog(null, "Inserire un username e una password");
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Inserire un username");
                }
            } else if (password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Inserire una password");
            }

            rs.close();
            return false;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            return false;
        }
    }

    public void RegistrazioneGiocatore(String SSN, String username, String password) {
        try (PreparedStatement st = conn.prepareStatement("INSERT INTO Credenziali VALUES(?, ?, ?, ?)")) {
            Statement st2 = conn.createStatement();
            st.setString(1, username);
            st.setString(2, password);
            st.setString(3, "Giocatore");
            st.setString(4, SSN);
            ResultSet rs = st2.executeQuery("SELECT * FROM Credenziali WHERE SSN = " + "'" + SSN + "'");
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "L'utente è già registrato!");
            } else {
                st.executeUpdate();
                JOptionPane.showMessageDialog(null, "Registrazione avvenuta con successo");
            }
            rs.close();
            st2.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    public void UpdateGiocatore(String nome, String cognome, String nazionalita, Date dataNascita,
                                char sesso, char piede, float altezza, float peso,
                                String ruolo, Boolean ritirato, String abilita, char TipoGiocatore, String SSN) {
        try (PreparedStatement st = conn.prepareStatement("UPDATE Giocatore SET Nome = ?, Cognome = ?, Nazionalita = ?, Datadinascita = ?," +
                " Sesso = ?, Piede = ?, Altezza = ?, Peso = ?, Ruolo = ?, Ritirato = ?, Abilita = ?, TipoGiocatore = ? WHERE SSN = ?")) {
            st.setString(1, nome);
            st.setString(2, cognome);
            st.setString(3, nazionalita);
            st.setDate(4,  dataNascita);
            st.setString(5, String.valueOf(sesso));
            st.setString(6, String.valueOf(piede));
            st.setFloat(7, altezza);
            st.setFloat(8, peso);
            st.setString(9, ruolo);
            st.setBoolean(10, ritirato);
            st.setString(11, abilita);
            st.setString(12, String.valueOf(TipoGiocatore));
            st.setString(13, SSN);
            st.executeUpdate();
            JOptionPane.showMessageDialog(null, "Modifica avvenuta con successo");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    public boolean ControlloSSNEsistente(String SSNGiocatore) {
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM Giocatore WHERE SSN = " + "'" + SSNGiocatore + "'")) {
            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            return false;
        }
    }
    public Giocatore getGiocatoreFromUsername(String username) {
        try(PreparedStatement st = conn.prepareStatement("SELECT * FROM Credenziali WHERE Username = ?")) {
            st.setString(1, username);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                String SSN = rs.getString("SSN");
                try (Statement st2 = conn.createStatement();
                     ResultSet rs2 = st2.executeQuery("SELECT * FROM Giocatore WHERE SSN = " + "'" + SSN + "'")) {
                    if (rs2.next()) {
                        return new Giocatore(rs2.getString("Nome"), rs2.getString("Cognome"), rs2.getString("SSN"),
                                rs2.getString("Nazionalita"), rs2.getDate("Datadinascita"), rs2.getString("Sesso").charAt(0),
                                rs2.getString("Piede").charAt(0), rs2.getFloat("Altezza"), rs2.getFloat("Peso"),
                                rs2.getString("Ruolo"), rs2.getBoolean("Ritirato"), rs2.getString("Abilita"), rs2.getString("TipoGiocatore").charAt(0));
                    }
                }
            }
            rs.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

        return null;
    }

    public void CarFisicheRicercaGiocatore(String nome, String cognome, Date dataNascita, String piede, String ruolo, String sesso, String ordineNascite)
    {
        try {
           // Statement st = conn.createStatement();
            // Inizializza la query di base
            StringBuilder query = new StringBuilder("SELECT * FROM giocatore WHERE 1 = 1");

            // Aggiungi le clausole WHERE solo per i parametri non nulli o non vuoti
            if (!nome.isEmpty()) {
                query.append(" AND nome = '").append(nome).append("'");
            }

            if (!cognome.isEmpty()) {
                query.append(" AND cognome = '").append(cognome).append("'");
            }

            if (!(piede.equals(" "))) {
                query.append(" AND piede = '").append(piede).append("'");
            }

            if (!ruolo.equals(" ")) {
                query.append(" AND ruolo = '").append(ruolo).append("'");
            }

            if (!sesso.equals(" ")) {
                query.append(" AND sesso = '").append(sesso).append("'");
            }
            if (!(dataNascita == null)) {
                query.append(" AND EXTRACT(YEAR FROM datadinascita) = ").append(dataNascita);
            }
            if (!ordineNascite.equals(" ")) {
                query.append(" ORDER BY datadinascita ").append(ordineNascite);
            }
            if (query.toString().equals("SELECT * FROM giocatore WHERE 1 = 1")) {
                JOptionPane.showMessageDialog(null, "Inserire almeno un parametro di ricerca");
            } else {
                //ResultSet rs = st.executeQuery(query.toString());
                String[] colonne = {"Nome", "Cognome", "SSN", "Nazionalita", "DataDiNascita", "Sesso", "Altezza", "Peso", "Ruolo", "Ritirato", "Abilita", "Piede", "TipoGiocatore"};
                TabellaDaQuery(query.toString(), colonne);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    public void TabellaDaQuery(String query, String[] colonne) {
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);

            ArrayList<String[]> datiList = new ArrayList<>();
            while (rs.next()) {
                String[] riga = new String[colonne.length];
                for (int i = 0; i < colonne.length; i++) {
                    riga[i] = rs.getString(colonne[i]);
                }
                datiList.add(riga);
            }

            String[][] dati = new String[datiList.size()][colonne.length];
            for (int i = 0; i < datiList.size(); i++) {
                dati[i] = datiList.get(i);
            }

            ResultTabella result = new ResultTabella(Controller.getCurrentFrame(), colonne, dati);

            rs.close();
            st.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
}
