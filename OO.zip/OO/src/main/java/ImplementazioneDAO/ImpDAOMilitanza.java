package ImplementazioneDAO;

import DAO.MilitanzaDAO;
import Database.ConnessioneDatabase;

import java.sql.*;

public class ImpDAOMilitanza implements MilitanzaDAO {
    private Connection conn;
    public ImpDAOMilitanza() {
        try {
            conn = ConnessioneDatabase.getInstance(2).connection;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void RicercaCarrieraGiocatore(String SSN)
    {
        //try{
            //Incompleto e sbagliato, da aggiustare
            //ImpDAOGiocatori.TabellaDaQuery("SELECT * FROM Militanza WHERE SSN = '" + SSN + "'", );
      //  } catch (SQLException e) {
            //throw new RuntimeException(e);
    }
    //}

}
