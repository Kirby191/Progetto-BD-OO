package Model;
import java.util.ArrayList;
import java.util.Date;

public class Giocatore {
    private String nome;
    private String cognome;
    private String SSN;
    private String nazionalita;
    private Date data_nascita;
    private String piede;
    private float altezza;
    private float peso;
    private String ruolo;
    private char sesso;
    private boolean ritirato;
    private String abilita;


    private ArrayList<Militanza> storico_militanze = new ArrayList<>();
    private ArrayList <Squadra> storico_squadre = new ArrayList<>();
    private ArrayList <Trofeo> trofei_vinti = new ArrayList<>();
    Allenatore allenatore = null;
    Dirigente dirigente = null;
    public Giocatore(Militanza c) {
        storico_militanze.add(c);
        c.setProprietario(this);
    }
    public Giocatore() {
    }
    public void ExGiocatoreA(Allenatore a) {
        // Giocatore deve essere ritirato: Controller
        allenatore = a;
        a.giocatore = this;
    }
    public void ExGiocatoreD(Dirigente d) {
        // Giocatore deve essere ritirato: Controller
        dirigente = d;
        d.giocatore = this;
    }
    public void addTrofeo(Trofeo t) {
        trofei_vinti.add(t);
    }
    public void addSquadra(Squadra s) {
        storico_squadre.add(s);
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setCognome(String cognome) {
        this.cognome = cognome;
    }
    public void setSSN(String SSN) {
        this.SSN = SSN;
    }
    public void setNazionalita(String nazionalita) {
        this.nazionalita = nazionalita;
    }
    public void setData_nascita(Date data_nascita) {
        this.data_nascita = data_nascita;
    }
    public void setPiede(String piede) {
        this.piede = piede;
    }
    public void setAltezza(float altezza) {
        this.altezza = altezza;
    }
    public void setPeso(float peso) {
        this.peso = peso;
    }
    public void setRuolo(String ruolo) {
        this.ruolo = ruolo;
    }
    public void setSesso(char sesso) {
        this.sesso = sesso;
    }
    public void setRitirato(boolean ritirato) {
        this.ritirato = ritirato;
    }
    public void setAbilita(String abilita) {
        this.abilita = abilita;
    }
    public String getNome() {
        return nome;
    }
    public String getCognome() {
        return cognome;
    }
    public String getSSN() {
        return SSN;
    }
    public String getNazionalita() {
        return nazionalita;
    }
    public Date getData_nascita() {
        return data_nascita;
    }
    public String getPiede() {
        return piede;
    }
    public float getAltezza() {
        return altezza;
    }
    public float getPeso() {
        return peso;
    }
    public String getRuolo() {
        return ruolo;
    }
    public char getSesso() {
        return sesso;
    }
    public boolean isRitirato() {
        return ritirato;
    }
    public String getAbilita() {
        return abilita;
    }
    public Allenatore getAllenatore() {
        return allenatore;
    }
    public Dirigente getDirigente() {
        return dirigente;
    }
    public ArrayList<Trofeo> getTrofei_vinti() {
        return trofei_vinti;
    }
    public ArrayList<Squadra> getStorico_squadre() {
        return storico_squadre;
    }
    public ArrayList<Militanza> getStorico_militanze() {
        return storico_militanze;
    }

    public void aggiuntiMilitanza(Militanza m) {
        storico_militanze.add(m);
    }
}