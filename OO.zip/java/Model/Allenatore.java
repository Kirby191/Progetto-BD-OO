package Model;
import java.util.ArrayList;

public class Allenatore {
    Giocatore giocatore = null;
    ArrayList<Squadra> squadre_allenate = new ArrayList<>();
    public Allenatore(Giocatore g, ArrayList<Squadra> s) {
        giocatore = g;
        squadre_allenate = s;
    }
}
