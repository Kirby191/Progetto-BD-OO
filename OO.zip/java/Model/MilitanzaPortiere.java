package Model;

public class MilitanzaPortiere extends Militanza{
    private int goal_subiti = 0;
    public MilitanzaPortiere(Giocatore g, Squadra s, int goal_subiti) {
        super(g, s);
        this.goal_subiti = goal_subiti;
    }
}
