package Model;
import java.util.Date;

public class Militanza {
    private Date data_inizio;
    private Date data_fine;
    private int PartiteGiocate;
    private int GolSegnati;
    private int CartelliniGialli;
    private int CartelliniRossi;
    private int Assist;


    private Giocatore proprietario;
    private Squadra squadra;
    public Militanza(Giocatore g, Squadra s) {
        proprietario = g;
        squadra = s;
        s.getMilitanze().add(this);
        g.getStorico_militanze().add(this);
        g.getStorico_squadre().add(squadra);
    }
    public Squadra getSquadra() {
        return squadra;
    }
    public Giocatore getProprietario() {
        return proprietario;
    }
    public void setProprietario(Giocatore g) {
        proprietario = g;
    }
}
