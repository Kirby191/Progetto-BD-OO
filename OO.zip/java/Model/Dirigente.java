package Model;
import java.util.ArrayList;
public class Dirigente {
    Giocatore giocatore = null;
    ArrayList<Squadra> Squadre_dirette = new ArrayList<>();
    public Dirigente(Giocatore g, ArrayList<Squadra> s) {
        giocatore = g;
        Squadre_dirette = s;
    }
}
